import time
import random
from multiprocessing import Lock, Condition, Process
from multiprocessing import Value

NORTH = "north"
SOUTH = "south"

NCARS = 100

class Monitor():
    def __init__(self):
        
        self.mutex = Lock()
        
        self.numeronorte = Value('i',0)
        self.numerosur = Value('i',0)
        
        self.novuelvenorte = Condition(self.mutex)
        self.novuelvesur = Condition(self.mutex)
        
        self.anticheatnorte = Condition(self.mutex)
        self.anticheatsur = Condition(self.mutex)
        
        self.haycochesnorte = Value('i', 0)
        self.haycochessur = Value('i', 0)
        
        self.tiempoesperandosur = Value('i',0)
        self.tiempoesperandonorte = Value('i',0)
        
        self.esperandosur = Value('i',0)
        self.esperandonorte = Value('i',0)
        
        self.hanpasadonorte = Value('i',0)
        self.hanpasadosur = Value('i',0)
    
    def tiempoNorte(self):
        
        return self.tiempoesperandonorte.value <= 7 #establecemos el limite en 7 (por ejemplo)
    
    def tiempoSur(self):
        
        return self.tiempoesperandosur.value <= 7 
    
    def norte(self):
        
        return self.numeronorte.value == 0
    
    def sur(self):
        
        return self.numerosur.value == 0
    
      
    def wants_enter(self, direction):
        self.mutex.acquire()
        
        if direction == SOUTH:
            
            self.haycochessur.value = 1
            self.esperandosur.value += 1
            self.anticheatsur.wait_for(self.tiempoNorte)
            self.novuelvenorte.wait_for(self.norte)
            self.esperandosur.value -= 1
            
            if self.esperandosur.value == 0:
               
                self.tiempoesperandosur.value = 0
           
            self.anticheatnorte.notify_all()
            self.haycochessur.value = 0
            
            if self.haycochesnorte.value >= 1:
               
                self.tiempoesperandonorte.value += 1
            
            self.numerosur.value += 1
            self.hanpasadosur.value += 1
            
        else:
           
            self.haycochesnorte.value = 1
            self.esperandonorte.value += 1
            self.anticheatnorte.wait_for(self.tiempoSur)
            self.novuelvesur.wait_for(self.sur)
            self.esperandonorte.value -= 1
            
            if self.esperandonorte.value == 0:
                
                self.tiempoesperandonorte.value = 0
            
            self.anticheatsur.notify_all()
            self.haycochesnorte.value = 0
            
            if self.haycochessur.value >= 1:
               
                self.tiempoesperandosur.value += 1
            
            self.numeronorte.value += 1
            self.hanpasadonorte.value += 1
            
        self.mutex.release()

    def leaves_tunnel(self, direction):
        
        self.mutex.acquire()
        
        if direction == SOUTH:
            
            self.numerosur.value -= 1
            self.novuelvesur.notify_all()
            
        else:
            
            self.numeronorte.value -= 1
            self.novuelvenorte.notify_all()
        
        self.mutex.release()

def delay(n=3):
    time.sleep(random.random()*n)

def car(cid, direction, monitor):
    print(f"car {cid} direction {direction} created")
    delay(6)
    print(f"car {cid} heading {direction} wants to enter")
    monitor.wants_enter(direction)
    print(f"car {cid} heading {direction} enters the tunnel")
    delay(3)
    print(f"car {cid} heading {direction} leaving the tunnel")
    monitor.leaves_tunnel(direction)
    print(f"car {cid} heading {direction} out of the tunnel")



def main():
    
    monitor = Monitor()
    cid = 0
    
    for _ in range(NCARS):
        
        direction = NORTH if random.randint(0,1)==1  else SOUTH
        cid += 1
        p = Process(target=car, args=(cid, direction, monitor))
        p.start()
        time.sleep(random.expovariate(1/0.5)) # a new car enters each 0.5s
        
        
if __name__=='__main__':
    main()