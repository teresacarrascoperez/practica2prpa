import time
import random
from multiprocessing import Lock, Condition, Process
from multiprocessing import Value

NORTH = "north"
SOUTH = "south"

NCARS = 100

class Monitor():
    
    def __init__(self):
        self.mutex = Lock()
        self.numeronorte = Value('i',0)
        self.numerosur = Value('i',0)
        self.novuelvenorte = Condition(self.mutex)
        self.novuelvesur = Condition(self.mutex)
    
    def norte(self):
        return self.numeronorte.value == 0
    
    def sur(self):
        return self.numerosur.value == 0
    
    def wants_enter(self, direction):
        self.mutex.acquire()
       
        if direction == SOUTH:
            self.novuelvenorte.wait_for(self.norte)
            self.numerosur.value += 1
            
        else:
            self.novuelvesur.wait_for(self.sur)
            self.numeronorte.value += 1
        
        self.mutex.release()

    def leaves_tunnel(self, direction):
        self.mutex.acquire()
        
        if direction == SOUTH:
            self.numerosur.value -= 1
            self.novuelvesur.notify_all()
            
        else:
            self.numeronorte.value -= 1
            self.novuelvenorte.notify_all()
        
        self.mutex.release()


def delay(n=3):
    time.sleep(random.random()*n)

def car(cid, direction, monitor):
    print(f"car {cid} direction {direction} created")
    delay(6)
    print(f"car {cid} heading {direction} wants to enter")
    monitor.wants_enter(direction)
    print(f"car {cid} heading {direction} enters the tunnel")
    delay(3)
    print(f"car {cid} heading {direction} leaving the tunnel")
    monitor.leaves_tunnel(direction)
    print(f"car {cid} heading {direction} out of the tunnel")



def main():
    monitor = Monitor()
    cid = 0
    for _ in range(NCARS):
        direction = NORTH if random.randint(0,1)==1  else SOUTH
        cid += 1
        p = Process(target=car, args=(cid, direction, monitor))
        p.start()
        time.sleep(random.expovariate(1/0.5)) # a new car enters each 0.5s
        
        
if __name__=='__main__':
    main()